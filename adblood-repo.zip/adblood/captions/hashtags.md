# ADBLOOD Hashtag Strategy

Maximum 15 hashtags per post. Always at the end of caption. Never mid-caption.

---

## The Mix (use this ratio every time)

| Type | Count | Examples |
|------|-------|---------|
| Mega (50M+ posts) | 1 | #marketing #advertising |
| Large (5–50M) | 2–3 | #marketingstrategy #branding #brandidentity |
| Medium (500K–5M) | 4–5 | #marketingtips #digitalmarketing #contentmarketing |
| Niche (under 500K) | 4–5 | #indianmarketing #marketingindia #adstrategy |
| Branded | 1 | #adblood |

---

## Pillar-Specific Additions

| Pillar | Extra tags to include |
|--------|----------------------|
| BREAKDOWN | #casestudy #brandstrategy #marketingcase |
| FACT DROP | #marketingfacts #brandfacts #didyouknow |
| ROAST | #marketingfail #adsfail #brandmistakes |
| MIND GAMES | #consumerpsychology #marketingpsychology #buyerbehaviour |
| STEAL THIS | #marketingtips #hookformula #instagramgrowth |

---

## Ready-to-Use Stack

Copy, paste, swap 2–3 pillar-specific tags at the end:

```
#marketing #marketingstrategy #branding #brandidentity #marketingtips
#digitalmarketing #contentmarketing #indianmarketing #marketingindia
#adstrategy #brandstrategy #marketingcase #instagramgrowth #adblood
```

---

## What Not to Do

- Never use hashtags in the middle of caption text
- Never exceed 15 (algorithm treats it as spam)
- Never use all mega tags — you'll drown in noise
- Never skip #adblood — it's your branded home base
