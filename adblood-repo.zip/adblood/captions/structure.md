# ADBLOOD Caption Structure

Every post caption follows this exact formula. No exceptions.

---

## Formula

```
[HOOK — same as poster or stronger. 1 line max.]

[2–3 lines of context / story]

[The insight or lesson — 1–2 lines]

[CTA — one of: "Save this." / "Tag someone." / "Which brand next?"]

[Hashtags — 15 max, see hashtags.md]
```

---

## Rules

- First line = the hook. If it doesn't stop your own scroll, rewrite it.
- Never start with "I" or "We"
- No hashtags mid-caption — always at the end
- CTA is always the last human line, hashtags after
- Caption detail belongs in the caption — not on the poster

---

## Example by Pillar

### FACT DROP

```
Nike paid ₹2,900 for the Swoosh. Here's what that tells you about branding.

In 1971, Carolyn Davidson was paid $35 to design the Nike tick.
Phil Knight wasn't even sure he liked it.
Today that logo is worth billions.

Not because of the design. Because of everything Nike built around it.
The logo doesn't make the brand. The brand makes the logo.

Save this. Next time someone says "just make a simple logo" — show them this.

#marketing #branding #marketingstrategy #brandidentity #marketingtips
#digitalmarketing #contentmarketing #indianmarketing #marketingindia
#adstrategy #brandstrategy #marketingfacts #brandfacts #instagramgrowth #adblood
```

### BREAKDOWN

```
Zomato doesn't sell food. They sell entertainment. Here's the full playbook.

While other food apps competed on discounts, Zomato competed on personality.
Their social media team had one rule: if it doesn't feel human, don't post it.
The result? A brand people follow even when they're not hungry.

Real lesson: In a commodity market, the brand with the most personality wins.
Not the one with the best product.

Which brand should I decode next? Drop below.

#marketing #branding #marketingstrategy #brandidentity #marketingcase
#digitalmarketing #contentmarketing #indianmarketing #marketingindia
#adstrategy #brandstrategy #casestudy #instagramgrowth #zomato #adblood
```

### ROAST

```
Pepsi spent $5M on an ad that got pulled in 24 hours. Here's what went wrong.

In 2017, Pepsi released an ad showing Kendall Jenner handing a can of Pepsi
to a police officer at a protest. The internet erupted.
Pepsi pulled it the next day and issued an apology.

The mistake: using real social pain as a brand aesthetic.
Consumers can smell inauthenticity from a mile away.

Tag a brand manager who needs to see this.

#marketing #branding #marketingstrategy #brandidentity #roast
#digitalmarketing #contentmarketing #indianmarketing #marketingindia
#adstrategy #marketingfail #adsfail #brandmistakes #instagramgrowth #adblood
```
