# ADBLOOD — We decode what sells

> **@adblood.in** · Gen Z · Street culture meets marketing intelligence

ADBLOOD is an Instagram marketing page that breaks down what makes brands and ads actually work. This repo contains the complete brand system, post templates, caption structures, and content calendar.

---

## Brand Identity

| Property | Value |
|----------|-------|
| Handle | @adblood.in |
| Tagline | We decode what sells |
| Vibe | Gen Z · Supreme energy · Hype Drop · Street culture meets marketing intelligence |

---

## Colour Palette

| Name | Hex | Role |
|------|-----|------|
| Crimson | `#C8102E` | Primary identity colour — always present |
| Cream | `#F5ECD7` | Primary text on dark backgrounds |
| Jet | `#0A0A0A` | Base background for most posts |
| Blood Dark | `#1A0005` | Punchline slides ONLY |
| Dust | `#9A8A70` | Borders and dividers only |

---

## Typography

- **Display / Headlines:** Archivo Black — ALL CAPS, letter-spacing -2 to -4px
- **Body / Captions:** Archivo Regular — 65–70% opacity on dark backgrounds
- **Key words:** Always in Crimson `#C8102E`

---

## The 5 Content Pillars

| Pillar | Format | Slides | Best For |
|--------|--------|--------|----------|
| BREAKDOWN | Carousel | 5–7 | Campaign dissections, brand playbooks |
| FACT DROP | Static | 1 | Shocking stats, one-punch moments |
| ROAST | Static / Carousel | 1–4 | Brand disasters, ad failures |
| MIND GAMES | Carousel | 4–5 | Marketing psychology, consumer behaviour |
| STEAL THIS | Carousel | 5–6 | Frameworks, hooks, templates |

---

## Mandatory Post Chrome

Every single post must have:
1. 6px left sidebar in Crimson
2. 5px top rule in Crimson
3. Corner slash triangle top-right in Crimson
4. Category badge top-left (Crimson bg, Cream text)
5. Mini stamp watermark bottom-left
6. Slide count / brand tag bottom-right

---

## Folder Structure

```
adblood/
├── brand/
│   ├── colours.css        # CSS variables for the full palette
│   ├── typography.css     # Font rules and hierarchy
│   └── logo-spec.md       # Logo construction rules
├── templates/
│   ├── fact-drop.svg      # Static post template
│   ├── breakdown.svg      # Carousel slide template
│   ├── roast.svg          # Roast template
│   ├── mind-games.svg     # Mind games template
│   └── steal-this.svg     # Steal this template
├── captions/
│   ├── structure.md       # Caption formula
│   └── hashtags.md        # Hashtag strategy by pillar
├── calendar/
│   └── weekly.md          # Weekly posting schedule
└── scripts/
    └── post-checklist.md  # Pre-publish quality check
```

---

## Weekly Calendar

| Day | Pillar | Format | Time IST |
|-----|--------|--------|----------|
| Monday | BREAKDOWN | Carousel | 8:00 AM |
| Tuesday | FACT DROP | Static | 7:00 PM |
| Wednesday | ROAST | Reel | 8:00 AM |
| Thursday | STEAL THIS | Carousel | 7:00 PM |
| Friday | MIND GAMES | Static | 6:00 PM |
| Saturday | BREAKDOWN | Carousel | 10:00 AM |
| Sunday | FACT DROP | Reel | 7:00 PM |

Batch on Sunday. Schedule via Meta Business Suite.

---

## Quick Start

```bash
git clone https://github.com/YOUR_USERNAME/adblood.git
cd adblood
```

Open any `.svg` template in Figma or Illustrator, swap text, export at 1080×1080px.
