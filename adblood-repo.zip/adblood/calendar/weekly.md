# ADBLOOD Weekly Content Calendar

Batch create on Sunday. Schedule via Meta Business Suite. Touch nothing all week.

---

| Day | Pillar | Format | Time IST | Why |
|-----|--------|--------|----------|-----|
| Monday | BREAKDOWN | Carousel | 8:00 AM | Highest reach day — lead with your strongest decode |
| Tuesday | FACT DROP | Static | 7:00 PM | Evening scroll — shocking stat hits harder |
| Wednesday | ROAST | Reel | 8:00 AM | Mid-week energy — Reels get pushed hard on Wed |
| Thursday | STEAL THIS | Carousel | 7:00 PM | Save-rate day — people plan ahead for the weekend |
| Friday | MIND GAMES | Static | 6:00 PM | Pre-weekend mindset — psychology lands here |
| Saturday | BREAKDOWN | Carousel | 10:00 AM | Leisure scroll — longer content works on Saturday |
| Sunday | FACT DROP | Reel | 7:00 PM | Wind-down scroll — one punch before the week |

---

## Batch Workflow (every Sunday)

1. Pick 7 topics — one per pillar slot
2. Write all captions first — fastest part
3. Build posts: Fact Drop → Roast → Breakdown → Steal This → Mind Games
4. Export all at 1080×1080 (posts) and 1080×1920 (Reels/Stories)
5. Schedule in Meta Business Suite
6. Do not edit posts after publishing — algorithm penalises edits

---

## Topic Bank Template

Keep a running doc in this format:

```
BREAKDOWN  — Fevicol: why the most boring product has India's most loved ads
FACT DROP  — Amul's entire ad budget vs what they made from it
ROAST      — The Pepsi protest ad ($5M wasted in 24 hours)
MIND GAMES — Why supermarkets put milk at the back
STEAL THIS — The 3-word hook formula that stops scrolls
BREAKDOWN  — How Swiggy Instamart built urgency into its brand
FACT DROP  — What Apple charges for 1 second of Super Bowl airtime
```
