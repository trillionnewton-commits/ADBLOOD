# ADBLOOD Logo Specification

## The Hype Drop Stamp

The primary logo mark is a Supreme-energy square stamp.

### Construction
- **Shape:** Square with slight border-radius (4px at standard size)
- **Background:** Crimson `#C8102E`
- **Offset shadow:** 3 layers, increasingly opaque
  - Layer 1: offset 2px 2px, opacity 15%
  - Layer 2: offset 4px 4px, opacity 30%
  - Layer 3: offset 6px 6px, opacity 50%
- **Text:** "AD" in Archivo Black, Cream `#F5ECD7`, centred
- **Details:** Small ink splat ellipses at corners, ★ stars, grain lines

### Wordmark
- "AD" in Archivo Black, Cream `#F5ECD7`, on Jet `#0A0A0A` background
- "BLOOD" in Archivo Black, Crimson `#C8102E`, on same Jet background
- No space between — they read as one word split by colour

### Mini Stamp (watermark)
Used bottom-left on every post.
- 20×20px square, Crimson bg
- "AD" in Archivo Black, Cream, 8px
- Followed by "ADBLOOD" wordmark in Archivo Black at 35% opacity

### Rules
- Never use medical / hospital aesthetics
- Never use red cross, droplet, or health iconography
- This is streetwear energy — think Supreme, not pharmacy
- Never stretch, rotate, or recolour the stamp
