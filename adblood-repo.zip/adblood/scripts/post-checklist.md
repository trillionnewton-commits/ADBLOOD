# ADBLOOD Pre-Publish Checklist

Run through this before every post goes live. No shortcuts.

---

## Visual

- [ ] 6px left sidebar in Crimson `#C8102E`
- [ ] 5px top rule in Crimson
- [ ] Corner slash triangle top-right in Crimson
- [ ] Category badge top-left — correct pillar name, Crimson bg, Cream text
- [ ] Mini stamp + ADBLOOD watermark bottom-left
- [ ] Slide count / @adblood.in bottom-right
- [ ] Background is Jet `#0A0A0A` (punchline slide only = Blood Dark `#1A0005`)
- [ ] Only one dominant visual element — nothing competing with it
- [ ] Key word(s) in Crimson only — no other accent colour used
- [ ] Font is Archivo Black for all headlines

## Copy (on the poster)

- [ ] Poster has hook + lesson ONLY — no caption-level detail
- [ ] Dominant stat / headline readable at thumb size (phone screen)
- [ ] Nothing that could be cut without losing meaning — cut it

## Caption

- [ ] First line is the hook — would it stop your own scroll?
- [ ] No hashtags mid-caption
- [ ] CTA is the last human line
- [ ] Exactly 15 hashtags at the end
- [ ] #adblood is included

## Format

- [ ] FACT DROP = Static only (never carousel)
- [ ] Carousel slide count matches pillar rule (BREAKDOWN: 5–7, never 8+)
- [ ] Punchline slide = Blood Dark bg, 7 words max
- [ ] CTA slide is last — no separate end card
- [ ] Export size: 1080×1080 (posts) or 1080×1920 (Reels/Stories)

---

Any unchecked box = do not publish. Fix first.
